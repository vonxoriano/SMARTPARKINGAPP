import { useEffect } from 'react';

/**
 * Confirm Modal — replaces window.confirm()
 *
 * Props:
 *   open      {boolean}   — whether the modal is visible
 *   title     {string}    — bold heading
 *   message   {string}    — body text
 *   onConfirm {function}  — called when user clicks the confirm button
 *   onCancel  {function}  — called when user clicks Cancel or the backdrop
 *   confirmLabel {string} — label for the confirm button (default "Confirm")
 *   confirmColor {string} — CSS background for confirm button (default red‑ish)
 *   icon      {string}    — emoji shown before the title (default "⚠️")
 */
export default function Modal({
  open,
  title = 'Are you sure?',
  message,
  onConfirm,
  onCancel,
  confirmLabel = 'Confirm',
  confirmColor = '#c0392b',
  icon = '⚠️',
}) {
  // Prevent body scroll while open
  useEffect(() => {
    if (open) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = '';
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === 'Escape') onCancel?.(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, onCancel]);

  if (!open) return null;

  return (
    <div
      onClick={onCancel}
      style={{
        position: 'fixed', inset: 0, zIndex: 9999,
        background: 'rgba(0,0,0,0.65)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        backdropFilter: 'blur(4px)',
        animation: 'fadeIn 0.18s ease',
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: 'linear-gradient(145deg, #2a1010, #1e0d0d)',
          border: '1px solid rgba(255,255,255,0.15)',
          borderRadius: '18px',
          padding: '32px 30px 26px',
          width: '90%',
          maxWidth: '380px',
          boxShadow: '0 20px 60px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.05)',
          color: 'white',
          animation: 'slideUp 0.22s cubic-bezier(0.34,1.56,0.64,1)',
          textAlign: 'center',
        }}
      >
        {/* Icon */}
        <div style={{ fontSize: '38px', marginBottom: '10px', lineHeight: 1 }}>{icon}</div>

        {/* Title */}
        <h3 style={{
          fontSize: '18px', fontWeight: '700', marginBottom: '10px',
          color: 'white', letterSpacing: '0.3px',
        }}>
          {title}
        </h3>

        {/* Message */}
        {message && (
          <p style={{
            fontSize: '14px', color: 'rgba(255,255,255,0.7)',
            marginBottom: '24px', lineHeight: 1.5,
          }}>
            {message}
          </p>
        )}

        {/* Buttons */}
        <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
          <button
            onClick={onCancel}
            style={{
              flex: 1, padding: '10px 0',
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.2)',
              borderRadius: '10px', color: 'white',
              fontSize: '14px', fontWeight: '600',
              cursor: 'pointer', transition: 'all 0.18s',
            }}
            onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.18)'}
            onMouseOut={e => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            style={{
              flex: 1, padding: '10px 0',
              background: confirmColor,
              border: 'none',
              borderRadius: '10px', color: 'white',
              fontSize: '14px', fontWeight: '700',
              cursor: 'pointer', transition: 'all 0.18s',
              boxShadow: `0 4px 14px ${confirmColor}66`,
            }}
            onMouseOver={e => e.currentTarget.style.opacity = '0.85'}
            onMouseOut={e => e.currentTarget.style.opacity = '1'}
          >
            {confirmLabel}
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; } to { opacity: 1; }
        }
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(24px) scale(0.96); }
          to   { opacity: 1; transform: translateY(0)     scale(1);    }
        }
      `}</style>
    </div>
  );
}
