import { useState, useEffect, useCallback } from 'react';

/**
 * Toast notification — replaces alert()
 *
 * Usage (imperative):
 *   import { showToast } from './Toast';
 *   showToast('Something went wrong', 'error');
 *   showToast('Done!', 'success');
 *   showToast('Please select a vehicle first', 'warning');
 *   showToast('Note: reservation is 1 hour', 'info');
 *
 * Mount <ToastContainer /> once at the app root (App.js).
 */

// ─── Event bus ────────────────────────────────────────────────────────────────
const listeners = new Set();

/** Call this anywhere in the app instead of alert() */
export function showToast(message, type = 'error', duration = 4000) {
  const id = Date.now() + Math.random();
  listeners.forEach((fn) => fn({ id, message, type, duration }));
}

// ─── Internal single toast ────────────────────────────────────────────────────
function Toast({ id, message, type, duration, onRemove }) {
  const [exiting, setExiting] = useState(false);

  const dismiss = useCallback(() => {
    setExiting(true);
    setTimeout(() => onRemove(id), 320);
  }, [id, onRemove]);

  useEffect(() => {
    const t = setTimeout(dismiss, duration);
    return () => clearTimeout(t);
  }, [dismiss, duration]);

  const palette = {
    success: { bg: '#1b4d2e', border: '#2ecc71', icon: '✅' },
    error:   { bg: '#4d1b1b', border: '#e74c3c', icon: '⚠️' },
    warning: { bg: '#4d3a1b', border: '#f39c12', icon: '⚡' },
    info:    { bg: '#1b2d4d', border: '#3498db', icon: 'ℹ️' },
  };
  const { bg, border, icon } = palette[type] || palette.info;

  return (
    <div
      onClick={dismiss}
      style={{
        display: 'flex', alignItems: 'flex-start', gap: '10px',
        background: bg,
        border: `1px solid ${border}`,
        borderLeft: `4px solid ${border}`,
        borderRadius: '12px',
        padding: '13px 16px',
        color: 'white',
        fontSize: '14px',
        lineHeight: '1.4',
        boxShadow: '0 6px 24px rgba(0,0,0,0.45)',
        cursor: 'pointer',
        maxWidth: '340px',
        width: '100%',
        animation: exiting
          ? 'toastOut 0.3s ease forwards'
          : 'toastIn 0.3s cubic-bezier(0.34,1.56,0.64,1)',
        transition: 'opacity 0.2s',
      }}
    >
      <span style={{ fontSize: '18px', flexShrink: 0 }}>{icon}</span>
      <span style={{ flex: 1 }}>{message}</span>
      <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: '16px', marginLeft: '4px', lineHeight: 1 }}>×</span>
    </div>
  );
}

// ─── Container — mount once in App.js ─────────────────────────────────────────
export function ToastContainer() {
  const [toasts, setToasts] = useState([]);

  useEffect(() => {
    const handler = (t) => setToasts((prev) => [...prev, t]);
    listeners.add(handler);
    return () => listeners.delete(handler);
  }, []);

  const remove = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <>
      <div
        style={{
          position: 'fixed', bottom: '24px', right: '24px', zIndex: 10000,
          display: 'flex', flexDirection: 'column-reverse', gap: '10px',
          pointerEvents: 'none',
        }}
      >
        {toasts.map((t) => (
          <div key={t.id} style={{ pointerEvents: 'auto' }}>
            <Toast {...t} onRemove={remove} />
          </div>
        ))}
      </div>

      <style>{`
        @keyframes toastIn {
          from { opacity: 0; transform: translateX(40px) scale(0.94); }
          to   { opacity: 1; transform: translateX(0)    scale(1);    }
        }
        @keyframes toastOut {
          from { opacity: 1; transform: translateX(0); }
          to   { opacity: 0; transform: translateX(40px); }
        }
      `}</style>
    </>
  );
}
